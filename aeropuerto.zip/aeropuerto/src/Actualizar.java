import java.sql.Connection;
import java.util.Scanner;

public class Actualizar {

    public static void actualizar(Connection con){
            String nombreTabla=Tablas.comprobarTabla(con);
            if(!(nombreTabla==null)){

            }else{
                System.out.println("esa tabla no existe");
            }



    }
}
