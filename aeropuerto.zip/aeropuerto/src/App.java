import java.sql.Connection;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Connection con;

        if (GestorConexion.crearConexion("aeropuerto", "user3", "A12345a")) {
            con = GestorConexion.getConexion();
            int opcion;

            do {
                System.out.println("\n===== MENÚ PRINCIPAL =====");
                System.out.println("1. Añadir");
                System.out.println("2. Eliminar");
                System.out.println("3. Búsqueda avanzada");
                System.out.println("4. Salir");
                System.out.print("Seleccione una opción: ");
                opcion = teclado.nextInt();
                teclado.nextLine(); // limpiar buffer

                switch (opcion) {
                    case 1:
                        // Aquí llamas al método de añadir
                        System.out.print("¿En qué tabla desea añadir un registro?: ");
                        String nombreTabla = teclado.nextLine();
                        AñadirBBDD.añadir(con,nombreTabla);
                        break;
                    case 2:
                        // Aquí llamas al método de eliminar
                        System.out.print("¿De qué tabla desea eliminar un registro?: ");
                        String nombreTablaEliminar = teclado.nextLine();
                        EliminarBBDD.eliminar(con,nombreTablaEliminar);
                        break;

                    case 3:
                        // Búsqueda avanzada
                        BusquedaAvanzada.extraerTablas(con);
                        break;
                    case 4:
                        System.out.println("Saliendo de la aplicación...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente de nuevo.");
                }

            } while (opcion != 5);

        } else {
            System.out.println("Error al conectar: " + GestorConexion.getError());
        }
    }
}
