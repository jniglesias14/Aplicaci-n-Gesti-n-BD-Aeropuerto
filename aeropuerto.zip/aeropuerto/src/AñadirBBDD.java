import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class AñadirBBDD {
    public static void añadir(Connection con,String nombre){
        String sql;
        boolean lectura=true;
        Scanner teclado=new Scanner(System.in);
        try{
            sql="select * from "+nombre;
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numeroColumnas = rsmd.getColumnCount();
            ArrayList<Object>lista=new ArrayList<>(numeroColumnas);
            while(rs.next() && lectura){
                for (int i = 1; i <= numeroColumnas; i++) {
                    String nombreColumna = rsmd.getColumnName(i);
                    /*
                    Object valor = rs.getObject(i);
                    System.out.println(nombreColumna + ": " + valor);
                    */
                    System.out.println(nombreColumna+":");
                    String valor=teclado.nextLine();
                    lista.add(convertidor(valor, rsmd.getColumnType(i)));

                }
                insertar(con,nombre,numeroColumnas,lista);
                lectura=false;
            }
        }catch (SQLException sqle){
            sqle.printStackTrace();
        }
    }

    public static void insertar(Connection con,String nombreTabla,int numeroColumnas,ArrayList<Object>lista){
        String sql;
        String texto="insert into "+nombreTabla+" values (";
        for(int i=1;i<=numeroColumnas;i++){
            if(i==numeroColumnas){
                texto=texto+"?)";
            }else {
                texto = texto + "?,";
            }
        }
        try{
            sql=texto;
            PreparedStatement ps=con.prepareStatement(sql);
            for(int i=0;i<numeroColumnas;i++) {
                ps.setObject(i+1,lista.get(i));
            }
            ps.executeUpdate();
            System.out.println(nombreTabla+" añadido");
        }catch (SQLException sqle){
            if(sqle.getErrorCode()==1062){
                System.out.println("ese valor ya esta introducido");
            } else if (sqle.getErrorCode()==1406) {
                System.out.println("error al introducir los datos");
            } else if (sqle.getErrorCode()==1452) {
                System.out.println("tienes que introducir un valor existente");
            } else {
                sqle.printStackTrace();
            }
        }


    }


    public static Object convertidor(String valor, int sqlType) {
        switch (sqlType) {
            case Types.BOOLEAN:
            case Types.BIT:
                return Boolean.parseBoolean(valor);
            case Types.INTEGER:
                return Integer.parseInt(valor);
            case Types.BIGINT:
                return Long.parseLong(valor);
            case Types.FLOAT:
            case Types.REAL:
                return Float.parseFloat(valor);
            case Types.DOUBLE:
                return Double.parseDouble(valor);
            case Types.DECIMAL:
                return new java.math.BigDecimal(valor);
            case Types.CHAR:
            case Types.VARCHAR:
                return valor;
            case Types.DATE:
                try {
                    return java.sql.Date.valueOf(valor);
                } catch (IllegalArgumentException e) {
                    System.out.println("Fecha en formato incorrecto. Use YYYY-MM-DD.");
                    return null;
                }
            case Types.TIME:
                try {
                    return java.sql.Time.valueOf(valor);
                } catch (IllegalArgumentException e) {
                    System.out.println("Hora en formato incorrecto. Use HH:MM:SS.");
                    return null;
                }
            case Types.TIMESTAMP:
                try {
                    return java.sql.Timestamp.valueOf(valor);
                } catch (IllegalArgumentException e) {
                    System.out.println("Fecha y hora en formato incorrecto. Usa YYYY-MM-DD HH:MM:SS.");
                    return null;
                }
            default:
                System.out.println("Tipo no soportado.");
                return null;
        }
    }


}



