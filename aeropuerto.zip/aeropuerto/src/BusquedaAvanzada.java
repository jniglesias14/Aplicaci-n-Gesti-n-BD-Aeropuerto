import java.sql.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

import static java.lang.System.*;

public class BusquedaAvanzada {

    public static void extraerTablas(Connection con) {
        out.println("estas tablas reciben estas foreign keys:");
        ArrayList<NombreTablas> listaTablas = new ArrayList<>();
        try {
            DatabaseMetaData dbmd = con.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, "%", new String[]{"TABLE"});
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                NombreTablas tabla = new NombreTablas(rs.getString("TABLE_NAME"));
                ResultSet rsColumns = dbmd.getColumns(null, null, tabla.nombre, null);
                while (rsColumns.next()) {
                    tabla.listaColumnas.add(rsColumns.getString("COLUMN_NAME"));
                }
                listaTablas.add(tabla);
            }
            extraerFK(con, listaTablas);
            seleccionTablas(con, listaTablas);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    public static void extraerFK(Connection con, ArrayList<NombreTablas> listaTablas) {
        try {
            DatabaseMetaData dbmd = con.getMetaData();
            for (int i = 0; i < listaTablas.size(); i++) {
                ResultSet rsForeignKeys = dbmd.getImportedKeys(null, null, listaTablas.get(i).nombre);
                while (rsForeignKeys.next()) {
                    String fkTableName = rsForeignKeys.getString("PKTABLE_NAME");
                    listaTablas.get(i).listaFK.add(new ForeignKeys(fkTableName));
                }

            }
            añadirColumnas(con, listaTablas);
            mostrar(listaTablas);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    public static void añadirColumnas(Connection con, ArrayList<NombreTablas> listaTablas) {
        for (int i = 0; i < listaTablas.size(); i++) {
            Iterator<ForeignKeys> ite = listaTablas.get(i).listaFK.iterator();
            while (ite.hasNext()) {
                ForeignKeys aux = ite.next();
                try {
                    String sql = "select * from " + aux.nombre;
                    PreparedStatement ps = con.prepareStatement(sql);
                    ResultSet rs = ps.executeQuery();
                    ResultSetMetaData rsmd = rs.getMetaData();
                    for (int j = 1; j <= rsmd.getColumnCount(); j++) {
                        String nombreColumna = rsmd.getColumnName(j);
                        aux.listaColumnas.add(nombreColumna);
                    }
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
            }
        }
    }




    public static void mostrar(ArrayList<NombreTablas> listaTablas) {
        for (int i = 0; i < listaTablas.size(); i++) {
            out.print(listaTablas.get(i).nombre + "\t------------>\t");
            Iterator<ForeignKeys> ite = listaTablas.get(i).listaFK.iterator();
            while ((ite.hasNext())) {
                ForeignKeys aux = ite.next();
                out.print(aux.nombre + "   ");
            }
            out.println();
        }
    }

    public static void seleccionTablas(Connection con, ArrayList<NombreTablas> listaTablas) {
        Scanner teclado = new Scanner(in);
        ArrayList<ContadorTablas> lista = new ArrayList<>();
        boolean lectura = true;
        while (lectura) {
            out.println("¿que tablas quieres seleccionar?");
            String nombre = teclado.nextLine();
            if (comprobarTabla(listaTablas, nombre)) {
                lista.add(new ContadorTablas(nombre));
                continue;
            } else {
                out.println("esa tabla no existe");
                lectura = false;
            }
        }
        if(lista.size()>1) {
            comprobarRelaciones(con, listaTablas, lista);
        }else{
            if(lista.isEmpty()){
                out.println("no has introducido ningun nombre");
            }else{
                ArrayList<NombreTablas>aux=new ArrayList<>();
                for(int i=0;i<listaTablas.size();i++){
                    if(listaTablas.get(i).nombre.equals(lista.getFirst().nombre)){
                        aux.add(listaTablas.get(i));
                    }
                }
                instruccion(con,aux);
            }
        }
    }

    public static void comprobarRelaciones(Connection con, ArrayList<NombreTablas> listaTablas, ArrayList<ContadorTablas> lista) {
        ArrayList<NombreTablas> listaBusqueda = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            for (int j = 0; j < listaTablas.size(); j++) {
                String nombreLista = lista.get(i).nombre.trim();
                String nombreTabla = listaTablas.get(j).nombre.trim();
                if (nombreLista.equalsIgnoreCase(nombreTabla)) {
                    listaBusqueda.add(listaTablas.get(j));
                }
            }
        }
        mostrar(listaBusqueda);
        if (relaciones(listaBusqueda, lista)) {
            out.println("esas tablas si tienen relacion");
            instruccion(con, listaBusqueda);
        } else {
            out.println("esas tablas no tiene relacion");
        }
    }

    public static boolean relaciones(ArrayList<NombreTablas> listaBusqueda, ArrayList<ContadorTablas> lista) {
        for (int i = 0; i < lista.size(); i++) {
            for (int j = 0; j < listaBusqueda.size(); j++) {
                if (lista.get(i).nombre.equals(listaBusqueda.get(j).nombre)) {
                    continue;
                } else {
                    Iterator<ForeignKeys> ite = listaBusqueda.get(j).listaFK.iterator();
                    while (ite.hasNext()) {
                        ForeignKeys aux = ite.next();
                        if (aux.nombre.equals(lista.get(i).nombre)) {
                            lista.get(i).contFuera++;
                        }
                    }
                }
            }
        }

        for (int i = 0; i < lista.size(); i++) {
            for (int j = 0; j < listaBusqueda.size(); j++) {
                if (lista.get(i).nombre.equals(listaBusqueda.get(j).nombre)) {
                    continue;
                } else {
                    Iterator<ForeignKeys> ite = listaBusqueda.get(j).listaFK.iterator();
                    while (ite.hasNext()) {
                        ForeignKeys aux = ite.next();
                        if (aux.nombre.equals(lista.get(i).nombre)) {
                            contDentro(listaBusqueda.get(j).nombre, lista);
                        }
                    }
                }
            }
        }


        for (ContadorTablas c : lista) {
            if (c.contFuera == 0 && c.contDentro == 0) {
                return false;
            }
        }
        return true;
    }

    public static void contDentro(String nombre, ArrayList<ContadorTablas> lista) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).nombre.equals(nombre)) {
                lista.get(i).contDentro++;
            }
        }
    }

    public static boolean comprobarTabla(ArrayList<NombreTablas> listaTablas, String nombre) {
        for (int i = 0; i < listaTablas.size(); i++) {
            if (listaTablas.get(i).nombre.equals(nombre)) {
                return true;
            }
        }
        return false;
    }
    public static void reducir(ArrayList<NombreTablas> listaBusqueda){
        for(int i=0;i<listaBusqueda.size();i++){
            Iterator<ForeignKeys> ite = listaBusqueda.get(i).listaFK.iterator();
            while(ite.hasNext()){
                ForeignKeys aux = ite.next();
                boolean lectura=true;
                for(int j=0;j<listaBusqueda.size() && lectura;j++){
                    if(aux.nombre.equals(listaBusqueda.get(j).nombre)){
                        lectura=false;
                    }
                }
                if(lectura){
                    ite.remove();
                }
            }
        }
        mostrar(listaBusqueda);
    }


        public static boolean instruccion(Connection con, ArrayList<NombreTablas> listaBusqueda) {
        Scanner teclado=new Scanner(System.in);
        ArrayList<String>listaTablas=new ArrayList<>();
        for (int i = 0; i < listaBusqueda.size(); i++) {
            out.println("-----------------------------");
            out.println(listaBusqueda.get(i).nombre);
            listaTablas.add(listaBusqueda.get(i).nombre);
            out.println("-----------------------------");
            for (int j = 0; j < listaBusqueda.get(i).listaColumnas.size(); j++) {
                out.println(listaBusqueda.get(i).listaColumnas.get(j));
            }
            out.println("-----------------------------");
        }
        reducir(listaBusqueda);
        boolean lectura=true;
        ArrayList<NombreTablas>listaElecciones=new ArrayList<>();
        while(lectura){
            out.println("dime el nombre de la tabla de la que quieres seleccionar la columna: ");
            String nombreTabla=teclado.nextLine();
            out.println("dime el nombre de la columna: ");
            String nombreColumna=teclado.nextLine();
            if(comprobarListaBusqueda(listaBusqueda,nombreTabla,nombreColumna)){
                if(comprobarListaElecciones(listaElecciones,nombreTabla,nombreColumna)){
                    if(comprobarNombreTabla(listaElecciones,nombreTabla)>=0){
                        int i=comprobarNombreTabla(listaElecciones,nombreTabla);
                        listaElecciones.get(i).listaColumnas.add(nombreColumna);
                    }else{
                        listaElecciones.add(new NombreTablas(nombreTabla));
                        int i=comprobarNombreTabla(listaElecciones,nombreTabla);
                        listaElecciones.get(i).listaColumnas.add(nombreColumna);
                    }

                }else{
                    out.println("esa columna ya esta metida");
                }
            }else {
                out.println("la tabla o la columna no existen");
            }
            out.println("deseea seguir (si/no):");
            String resp=teclado.nextLine();
            if(resp.equals("no")){
                lectura=false;
            }
        }
        if(listaElecciones.isEmpty()){
            return false;
        }
       for(int i=0;i<listaElecciones.size();i++){
           out.println("--------------");
           out.println(listaElecciones.get(i).nombre);
           out.println("--------------");
           for(int j=0;j<listaElecciones.get(i).listaColumnas.size();j++){
               out.println(listaElecciones.get(i).listaColumnas.get(j));
           }
           out.println("--------------");
           out.println();
           out.println();
       }


        out.println();
        out.println();
        out.println("estan son las columnas que relacionan las tablas");
        out.println();

            extraerPK(con,listaBusqueda);

            ArrayList<FK> listaFKS=extraerPK(con,listaBusqueda);
            Collections.sort(listaFKS, new Comparator<FK>() {
                @Override
                public int compare(FK fk1, FK fk2) {
                    // Primero comparamos por la cantidad de relaciones (de más a menos)
                    int compareRelaciones = Integer.compare(fk2.listaRelaciones.size(), fk1.listaRelaciones.size());
                    if (compareRelaciones != 0) {
                        return compareRelaciones;
                    }

                    // Si tienen el mismo número de relaciones, verificamos si una tabla está en las relaciones de la otra
                    if (fk1.listaRelaciones.contains(fk2.nombre)) {
                        return 1; // fk1 depende de fk2
                    } else if (fk2.listaRelaciones.contains(fk1.nombre)) {
                        return -1; // fk2 depende de fk1
                    }

                    // Si no hay una relación directa, las ordenamos por nombre de tabla para consistencia
                    return fk1.nombre.compareTo(fk2.nombre);
                }
            });

           mostrarNombreTablas(listaFKS);
            mostrarListas(listaFKS);

            ejecucionInstruccion(con,listaFKS,listaElecciones);




        return true;
    }
    public static void mostrarNombreTablas(ArrayList<FK>listaFKS){
        for(int i=0;i<listaFKS.size();i++){
            out.print(listaFKS.get(i).nombre);
            out.print("---------->");
            for(int j=0;j<listaFKS.get(i).listaRelaciones.size();j++){
                out.print(listaFKS.get(i).listaRelaciones.get(j).nombre+"    ");
            }
            out.println();
        }
    }

    public static ArrayList<FK> extraerPK(Connection con, ArrayList<NombreTablas> listaBusqueda){
        ArrayList<FK> listaFKS =new ArrayList<>();
        try{
            DatabaseMetaData dbmd=con.getMetaData();
            for(int i=0;i<listaBusqueda.size();i++){
                if(listaBusqueda.get(i).listaFK.isEmpty()) {
                    ArrayList<String> pk = new ArrayList<>();
                    ResultSet rs = dbmd.getPrimaryKeys(null, null, listaBusqueda.get(i).nombre);
                    while (rs.next()) {
                        pk.add(rs.getString("COLUMN_NAME"));
                    }
                    listaFKS.add(new FK(listaBusqueda.get(i).nombre));
                    for (int j = 0; j < pk.size(); j++) {
                        listaFKS.get(i).listaFk.add(pk.get(j));
                    }
                    pk.clear();
                }else{
                    listaFKS.add(new FK(listaBusqueda.get(i).nombre));
                    Iterator<ForeignKeys>ite=listaBusqueda.get(i).listaFK.iterator();
                    int cont=0;
                    while(ite.hasNext()){
                        ForeignKeys aux=ite.next();
                        listaFKS.get(i).listaRelaciones.add(new RelacionesFK(aux.nombre));
                        ArrayList<String> pk = new ArrayList<>();
                        ResultSet rs = dbmd.getPrimaryKeys(null, null, aux.nombre);
                        while (rs.next()) {
                            pk.add(rs.getString("COLUMN_NAME"));
                        }
                        for(int z=0;z<pk.size();z++){
                            listaFKS.get(i).listaRelaciones.get(cont).lista.add(pk.get(z));

                        }
                        cont++;
                        pk.clear();


                    }
                }
            }

            extraerFKS(listaBusqueda,listaFKS);


        }catch(SQLException sqle){
            sqle.printStackTrace();
        }
        return listaFKS;
    }

    public static void mostrarListas(ArrayList<FK>listaFKS){
        for(int i=0;i<listaFKS.size();i++){
            out.println("-------------");
            out.println(listaFKS.get(i).nombre);
            out.println("-------------");
            for(int j=0;j<listaFKS.get(i).listaFk.size();j++){
                out.println(listaFKS.get(i).listaFk.get(j));
            }
            out.println("-------------");
            out.println("tablas con las que se relaciona");
            for(int z=0;z<listaFKS.get(i).listaRelaciones.size();z++){
                out.println("-------------");
                out.println(listaFKS.get(i).listaRelaciones.get(z).nombre);
                out.println("-------------");
                for(int k=0;k<listaFKS.get(i).listaRelaciones.get(z).lista.size();k++){
                    out.println(listaFKS.get(i).listaRelaciones.get(z).lista.get(k));
                }
                out.println("-------------");

            }
            out.println("siguiente tabla");

        }
    }

    public static void extraerFKS(ArrayList<NombreTablas> listaBusqueda,ArrayList<FK>lista){

        for(int i=0;i<lista.size();i++){
            if(lista.get(i).listaFk.isEmpty()){
                for(int j=0;j<lista.get(i).listaRelaciones.size();j++){
                    for(int z=0;z<lista.get(i).listaRelaciones.get(j).lista.size();z++) {
                        String fk = foreignKey(lista.get(i).listaRelaciones.get(j).nombre, listaBusqueda, lista);
                        if (fk != null) {  // Validación de fk no nula
                            lista.get(i).listaFk.add(fk);
                        }
                    }
                }
            }
        }
    }
    public static String foreignKey(String nombreTabla,ArrayList<NombreTablas>listaBusqueda,ArrayList<FK>lista){
        for(int i=0;i<listaBusqueda.size();i++){
            for(int j=0;j<listaBusqueda.get(i).listaColumnas.size();j++){
                if(listaBusqueda.get(i).listaColumnas.get(j).contains(nombreTabla) ){
                   if( comprobarListaFKS(lista,listaBusqueda.get(i).listaColumnas.get(j),listaBusqueda.get(i).nombre)) {
                       return listaBusqueda.get(i).listaColumnas.get(j);
                   }

                }
            }

        }

        return null;
    }

    public static boolean comprobarListaFKS(ArrayList<FK>lista,String nombreColumna,String nombreTabla){
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).nombre.equals(nombreTabla)){
                for(int j=0;j<lista.get(i).listaFk.size();j++){
                    if(lista.get(i).listaFk.get(j).equals(nombreColumna)){
                        return false;
                    }
                }
            }
        }
        return true;
    }



    public static int comprobarNombreTabla(ArrayList<NombreTablas>lista,String nombre){
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).nombre.equals(nombre)){
                return i;
            }
        }
        return -1;
    }
    public static boolean comprobarListaBusqueda(ArrayList<NombreTablas>lista,String nombreTabla,String columna){
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).nombre.equals(nombreTabla)){
                for(int j=0;j<lista.get(i).listaColumnas.size();j++){
                    if(lista.get(i).listaColumnas.get(j).equals(columna)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    public static boolean comprobarListaElecciones(ArrayList<NombreTablas>lista,String nombreTabla,String columna){
        for(int i=0;i<lista.size();i++){
            if(lista.get(i).nombre.equals(nombreTabla)){
                for(int j=0;j<lista.get(i).listaColumnas.size();j++){
                    if(lista.get(i).listaColumnas.get(j).equals(columna)){
                        return false;
                    }
                }
            }
        }
        return true;
    }


    public static void ejecucionInstruccion(Connection con,ArrayList<FK>listaFKS,ArrayList<NombreTablas>listaElecciones){
        String sql=" ";
        Scanner teclado=new Scanner(System.in);
        for(int i=0;i<listaElecciones.size();i++){
            for(int j=0;j<listaElecciones.get(i).listaColumnas.size();j++) {
                if (i == 0 && j==0) {
                    sql = sql + "select " + listaElecciones.get(i).nombre + "." + listaElecciones.get(i).listaColumnas.get(j);
                } else if (i==listaElecciones.size()-1 && j==listaElecciones.get(i).listaColumnas.size()-1) {
                    sql=sql+","+listaElecciones.get(i).nombre + "." + listaElecciones.get(i).listaColumnas.get(j);
                } else{
                    sql=sql+","+listaElecciones.get(i).nombre + "." + listaElecciones.get(i).listaColumnas.get(j);
                }
            }
        }

        for(int i=0;i<listaFKS.size();i++){
            String nombreTabla=listaFKS.get(i).nombre;
            if (i == 0) {
                sql=sql+" from "+nombreTabla+" "+nombreTabla;
            }else{
                if(numeroColumnas(nombreTabla,listaFKS)>0){
                    if(numeroColumnas(nombreTabla,listaFKS)>listaFKS.get(i).listaRelaciones.size()){
                        /* join using*/
                        String aux="";
                        String nombreTablaRelacion=devolucionNombreTabla(listaFKS,nombreTabla);
                        ArrayList<String> listaColumnasTabla=devolucionNombreColumnasFK(listaFKS,nombreTabla);
                        ArrayList<String> listaColumnasTablaRelacion=ordenar(devolucionNombreColumnas(listaFKS,nombreTabla),listaColumnasTabla);
                        for(int q=0;q<listaColumnasTabla.size();q++) {
                            if (q < listaColumnasTabla.size() - 1) {
                                aux = aux + nombreTabla + "." + listaColumnasTabla.get(q) + "=" + nombreTablaRelacion + "." + listaColumnasTablaRelacion.get(q) + " and ";
                            }else{
                                aux = aux + nombreTabla + "." + listaColumnasTabla.get(q) + "=" + nombreTablaRelacion + "." + listaColumnasTablaRelacion.get(q);

                            }
                        }
                        sql=sql+" join "+nombreTabla+" "+nombreTabla+" on("+aux+")";
                    }else{
                        String nombreTablaRelacion=devolucionNombreTabla(listaFKS,nombreTabla);
                        String nombreTablaRelacionColumna=devolucionNombreColumna(listaFKS,nombreTabla);
                        String nombreTablaColumna=devolucionNombreColumnaFK(listaFKS,nombreTabla);
                        sql=sql+" join "+nombreTabla+" "+nombreTabla+" on("+nombreTabla+"."+nombreTablaColumna+"="+nombreTablaRelacion+"."+nombreTablaRelacionColumna+")";
                    }
                } else if (numeroColumnas(nombreTabla,listaFKS)==0) {
                    /*no tiene foreign keys relacionadas a la derecha*/
                    String nombreTablaRelacion=devolucionNombreTabla(listaFKS,nombreTabla);
                    String nombreTablaRelacionColumna=devolucionNombreColumna(listaFKS,nombreTabla);
                    String nombreTablaColumna=devolucionNombreColumnaFK(listaFKS,nombreTabla);
                    sql=sql+" join "+nombreTabla+" "+nombreTabla+" on("+nombreTabla+"."+nombreTablaColumna+"="+nombreTablaRelacion+"."+nombreTablaRelacionColumna+")";

                }else{
                    out.println("error");
                }
            }
        }
        out.println("desea añadir alguna restriccion (si/no):");
        String respuesta=teclado.nextLine();
        if(respuesta.equals("si")){
            String linea=restricciones(con,sql,listaFKS);
            sql+=linea;
        } else if (respuesta.equals("no")) {

        }else{
            out.println("error");
        }
        sql=sql+";";
        out.println(sql);

        instruccion(con,sql,listaElecciones);

    }
    public static int numeroColumnas(String nombreTabla,ArrayList<FK>listaFKS){
        String nombre=devolucionNombreTabla(listaFKS,nombreTabla);
        for(int i=0;i<listaFKS.size();i++){
            if(listaFKS.get(i).nombre.equals(nombre)){
                if(!(listaFKS.get(i).listaRelaciones.isEmpty())){
                    return listaFKS.get(i).listaFk.size();
                }else{
                    return 0;
                }
            }
        }
        return -1;
    }
    public static String devolucionNombreTabla(ArrayList<FK>listaFKS,String nombreTabla){
        for(int i=0;i<listaFKS.size();i++){
            for(int j=0;j<listaFKS.get(i).listaRelaciones.size();j++){
                if(listaFKS.get(i).listaRelaciones.get(j).nombre.equals(nombreTabla)){
                    return listaFKS.get(i).nombre;
                }
            }
        }
        return null;
    }

    public static String devolucionNombreColumna(ArrayList<FK>listaFKS,String nombreTabla){

        for(int i=0;i<listaFKS.size();i++){
            for(int j=0;j<listaFKS.get(i).listaRelaciones.size();j++){
                if(listaFKS.get(i).listaRelaciones.get(j).nombre.equals(nombreTabla)){
                    for(int z=0;z<listaFKS.get(i).listaFk.size();z++){
                        if(z==j) {
                            return listaFKS.get(i).listaFk.get(z);
                        }
                    }
                }
            }
        }
        return null;
    }
    public static String devolucionNombreColumnaFK(ArrayList<FK>listaFKS,String nombreTabla){
        for(int i=0;i<listaFKS.size();i++) {
            for (int j = 0; j < listaFKS.get(i).listaRelaciones.size(); j++) {
                if(listaFKS.get(i).listaRelaciones.get(j).nombre.equals(nombreTabla)){
                    return listaFKS.get(i).listaRelaciones.get(j).lista.getFirst();
                }
            }
        }
        return null;
    }
    public static ArrayList<String> devolucionNombreColumnas(ArrayList<FK>listaFKS,String nombreTabla){
        ArrayList<String> lista=new ArrayList<>();
        for(int i=0;i<listaFKS.size();i++){
            for(int j=0;j<listaFKS.get(i).listaRelaciones.size();j++){
                if(listaFKS.get(i).listaRelaciones.get(j).nombre.equals(nombreTabla)){
                    for(int z=0;z<listaFKS.get(i).listaFk.size();z++){
                        if(listaFKS.get(i).listaFk.get(z).contains(nombreTabla)){
                            lista.add(listaFKS.get(i).listaFk.get(z));
                        }
                    }
                }
            }
        }
        return lista;
    }
    public static ArrayList<String> devolucionNombreColumnasFK(ArrayList<FK>listaFKS,String nombreTabla){

        ArrayList<String> lista=new ArrayList<>();
        for(int i=0;i<listaFKS.size();i++){
            for(int j=0;j<listaFKS.get(i).listaRelaciones.size();j++){
                if(listaFKS.get(i).listaRelaciones.get(j).nombre.equals(nombreTabla)){
                    for(int z=0;z<listaFKS.get(i).listaRelaciones.get(j).lista.size();z++){
                        lista.add(listaFKS.get(i).listaRelaciones.get(j).lista.get(z));
                    }
                }
            }
        }
        return lista;
    }
    public static ArrayList<String> ordenar( ArrayList<String>aux,ArrayList<String> lista){
        ArrayList<String>copia=new ArrayList<>();
        for(int i=0;i<lista.size();i++){
            for(int j=0;j<aux.size();j++){
                if(aux.get(j).contains(lista.get(i))){
                    copia.add(aux.get(j));
                }
            }
        }
        return copia;
    }


    public static void instruccion(Connection con,String sql,ArrayList<NombreTablas>listaElecciones){
        try{
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while ((rs.next())){
                for(int i=0;i<listaElecciones.size();i++) {
                    for(int j=0;j<listaElecciones.get(i).listaColumnas.size();j++){
                        out.print(rs.getString(listaElecciones.get(i).nombre+"."+listaElecciones.get(i).listaColumnas.get(j)));
                        out.print("  ");
                    }
                    rs.getClass();
                }
                out.println();
            }
        }catch (SQLException sqle){
            sqle.printStackTrace();
        }
    }

    public static String restricciones(Connection con,String sql,ArrayList<FK>listaFKS){
        Scanner teclado=new Scanner(System.in);
        boolean lectura=true;
        String linea=" where ";
        while(lectura){
            out.println("nombre de la tabla");
            String nombreTabla=teclado.nextLine();
            out.println("nombre de la columna");
            String nombreColumna=teclado.nextLine();
            if(comprobarListaFKS(listaFKS,nombreTabla,nombreColumna)==true){
                if(comprobarRestriccion(con,nombreTabla,nombreColumna).equals("INTEGER") || comprobarRestriccion(con,nombreTabla,nombreColumna).equals("DECIMAL") ||
                        comprobarRestriccion(con,nombreTabla,nombreColumna).equals("DATE") || comprobarRestriccion(con,nombreTabla,nombreColumna).equals("TIMESTAMP")){
                   String simbolo=simbolo();
                    out.println("escribe el valor de la restriccion");
                    String valor=teclado.nextLine();
                    linea=linea+nombreTabla+"."+nombreColumna+simbolo+valor;


                }else{
                    out.println("escribe el valor de la restriccion");
                    String valor=teclado.nextLine();
                    linea=linea+nombreTabla+"."+nombreColumna+"= '"+valor+"'";
                }
                String continuacion=continuacion(teclado);
                if(!continuacion.equals("-1")){
                    linea+=continuacion;
                }else{
                    lectura=false;
                }

            }else{
                out.println("error al introducir los nombres");
            }
        }
        return linea;
    }
    public static String continuacion(Scanner teclado){
        out.println("desea finalizar la instruccion (si/no):");
        String respuesta=teclado.nextLine();
        if(respuesta.equals("si")){
            return "-1";
        }else{
            out.println("que desea poner una y para que se tenga que cumplir la siguiente instruccion o una o para que solo se cumpla una (y/o):");
            out.println("y = &&");
            out.println("o = ||");
            String opcion=teclado.nextLine();
            if(opcion.equals("y")){
                return " && ";
            } else if (opcion.equals("o")) {
                return " || ";
            }else{
                return "-1";
            }
        }
    }

    public static String simbolo(){
        Scanner teclado=new Scanner(System.in);
        out.println("que simbolo desea utilizar:");
        out.println("1) >=");
        out.println("2) <=");
        out.println("3) =");
        out.println("4) >");
        out.println("5) <");
        int opcion=Integer.parseInt(teclado.nextLine());
        if(opcion==1){
            return ">=";
        } else if (opcion==2) {
            return "<=";
        } else if (opcion==3) {
            return "=";
        } else if (opcion==4) {
            return ">";
        } else if (opcion==5) {
            return "<";
        }else{
            return null;
        }
    }

    public static String comprobarRestriccion(Connection con,String nombreTabla,String nombreColumna){
        String sql;
        try{
            sql="select "+nombreColumna+" from "+nombreTabla;
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            ResultSetMetaData rsmd=rs.getMetaData();
            int tipoDato = rsmd.getColumnType(1);
            return obtenerNombreTipo(tipoDato);
        }catch (SQLException sqle){
            sqle.printStackTrace();
        }
        return null;
    }
    public static String obtenerNombreTipo(int tipoDato) {
        switch (tipoDato) {
            case Types.VARCHAR:
                return "VARCHAR";
            case Types.CHAR:
                return "CHAR";
            case Types.INTEGER:
                return "INTEGER";
            case Types.DATE:
                return "DATE";
            case Types.TIMESTAMP:
                return "TIMESTAMP";
            case Types.DECIMAL:
                return "DECIMAL";
            // Añadir más casos según sea necesario
            default:
                return "OTRO_TIPO";
        }
    }
}
