public class Columna implements Comparable<Columna>{
    public String nombre;
    public String tipo;
    public Columna(String n,String t){
        this.nombre=n;
        this.tipo=t;
    }
    public Columna(String n){
        this.nombre=n;
    }
    public int compareTo(Columna otra) {
        return this.nombre.compareTo(otra.nombre);
    }
    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
     return tipo;
    }


}
