import java.util.ArrayList;

public class ContadorTablas {
    public String nombre;
    public int contDentro;
    public int contFuera;
    public ArrayList<RelacionesFK> lista;
    public ContadorTablas(String n){
        nombre=n;
        contDentro=0;
        contFuera=0;
        lista=new ArrayList<>();
    }
}
