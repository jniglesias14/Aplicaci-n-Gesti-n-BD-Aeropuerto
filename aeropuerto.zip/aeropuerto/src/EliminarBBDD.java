import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class EliminarBBDD {

    /*
    public static void eliminarPK(Connection con, String nombre) {
        String sql;
        try {
            sql = "select * from " + nombre;
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            DatabaseMetaData dbmd = con.getMetaData();
            ResultSet rs2 = dbmd.getPrimaryKeys(null, null, nombre);
            ArrayList<String> lista1 = new ArrayList<>();
            while (rs2.next()) {
                lista1.add(rs2.getString("COLUMN_NAME"));
            }
            /*
            ArrayList<Columna>lista2=new ArrayList<>();
            for(int i=1;i<=rsmd.getColumnCount();i++){
                if(lista1.contains(rsmd.getColumnName(i))){
                    lista2.add(new Columna(lista1.get(i-1),rsmd.getColumnType(i)));
                }
            }


            delete(con, lista1, nombre);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }
*/
    public static void delete(Connection con, TreeSet<Columna> lista, String nombre) {
        Scanner teclado = new Scanner(System.in);
        String sql = "delete from " + nombre + " where ";
        ArrayList<String> datos = new ArrayList<>();
        Iterator<Columna>ite=lista.iterator();
        int i=0;
        try {
            while(ite.hasNext()) {
                Columna aux=ite.next();
                System.out.println(aux.nombre + ": ");
                String dato = teclado.nextLine();
                datos.add(dato);
                if (i == 0) {
                    sql = sql + aux.nombre + " = '" + dato+"'";
                } else {
                    sql = sql + " and " + aux.nombre + " = '" + dato+"'";
                }
                i++;
            }
            boolean datosVacios = datos.stream().allMatch(String::isEmpty);
            if(datosVacios) {
                System.out.println("no has introducido ningun valor");
            }else{

                if (comprobar(con, nombre, lista, datos).equals("2")) {
                    System.out.println("esos datos no existen");
                } else if (comprobar(con, nombre, lista, datos).equals("1")) {
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.executeUpdate();
                    System.out.println("Elemento eliminado");
                }
            }

        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    public static String comprobar(Connection con, String nombreTabla, TreeSet<Columna> lista, ArrayList<String> datos) {
        String sql = "select * from " + nombreTabla + " where ";
        Iterator<Columna>ite= lista.iterator();
        int i=0;
        try {
            while(ite.hasNext()) {
                Columna aux=ite.next();
                if (i == 0) {
                    sql = sql + aux.nombre + " = '" +datos.get(i)+"'";
                } else {
                    sql = sql + " and " + aux.nombre + " = '" + datos.get(i)+"'";
                }
                i++;
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return "1";
            } else {
                return "2";
            }
        } catch (SQLException sqle) {
            if(sqle.getErrorCode()==1525){
                System.out.println("el dato introducido no existe");
                return "3";
            }else {
                sqle.printStackTrace();
                return "3";
            }
        }
    }


    public static void eliminar(Connection con, String nombre) {
        String sql;
        try {
            sql = "select * from " + nombre;
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            DatabaseMetaData dbmd = con.getMetaData();
            TreeSet<Columna> lista1 = new TreeSet<>();
            ResultSet rs2 = dbmd.getPrimaryKeys(null, null, nombre);
            ArrayList<Columna> lista2 = new ArrayList<>();
            while (rs2.next()) {
                lista1.add(new Columna(rs2.getString("COLUMN_NAME"),"pk"));
            }
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                lista2.add(new Columna(rsmd.getColumnName(i)));
            }
            for(int i=0;i<lista2.size();i++){
                lista1.add(lista2.get(i));
            }
            TreeSet<Columna> copia=new TreeSet<>();
            copia=elegir(con,lista1);
            if(copia.isEmpty()){
                System.out.println("no has elegido nada");
            }else {
                delete(con, copia, nombre);
            }

        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    public static TreeSet<Columna> elegir(Connection con, TreeSet<Columna> lista2){
        Scanner teclado=new Scanner(System.in);
        Iterator<Columna> ite= lista2.iterator();
        while(ite.hasNext()) {
            Columna aux=ite.next();
            System.out.println("quieres eliminar por " + aux.nombre + " (si/no)");
            String respuesta = teclado.nextLine();
            if (respuesta.equals("si")) {
                continue;
            } else if (respuesta.equals("no")) {
                ite.remove();
            } else {
                System.out.println("error");
                ite.remove();
            }
        }
        return lista2;
    }
}

