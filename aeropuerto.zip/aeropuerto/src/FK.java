import java.util.ArrayList;

public class FK {
    public String nombre;
    public ArrayList<String> listaFk;
    public ArrayList<RelacionesFK> listaRelaciones;
    public FK(String n){
        this.nombre=n;
        listaFk=new ArrayList<>();
        listaRelaciones=new ArrayList<>();
    }
}
