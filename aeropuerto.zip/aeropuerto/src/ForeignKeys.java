import java.util.*;

public class ForeignKeys implements Comparable<ForeignKeys>{
    public String nombre;
    public ArrayList<String> listaColumnas;
    public ForeignKeys(String n){
        this.nombre=n;
        this.listaColumnas=new ArrayList<>();

    }


    public void mostrar(){

        for(int i=0;i< listaColumnas.size();i++){
            System.out.println(listaColumnas.get(i));
        }
        System.out.println("-----------------------");

    }
    public void ver3(){
        System.out.println("-----------------------");
        System.out.println(this.nombre);
        System.out.println("-----------------------");
        for(int i=0;i<listaColumnas.size();i++){
            System.out.println(listaColumnas.get(i));
        }
        System.out.println("-----------------------");
    }

    @Override
    public int compareTo(ForeignKeys o) {
        return this.nombre.compareTo(o.nombre);
    }
}
