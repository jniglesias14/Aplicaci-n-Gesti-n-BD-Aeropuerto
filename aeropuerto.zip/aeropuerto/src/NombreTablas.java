import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class NombreTablas {
    public String nombre;
    public ArrayList<String> listaColumnas;
    public TreeSet<ForeignKeys> listaFK;
    public NombreTablas(String n){
        this.nombre=n;
        this.listaColumnas=new ArrayList<>();
        this.listaFK=new TreeSet<>();
    }
    public void mostrar(){
        for(int i=0;i<listaColumnas.size();i++){
            System.out.println(listaColumnas.get(i));

        }
        System.out.println("-----------------------");
    }
    public void ver(){
        Iterator<ForeignKeys>ite=listaFK.iterator();
        while(ite.hasNext()){
            ForeignKeys aux=ite.next();
            System.out.println("-----------------------");
            System.out.println(aux.nombre);
            System.out.println("-----------------------");
            aux.mostrar();
        }
    }

    public void ver1(){
        System.out.println("--------------");
        System.out.println(this.nombre);
        System.out.println("--------------");
        for(int i=0;i<listaColumnas.size();i++){
            System.out.println(listaColumnas.get(i));
        }
        System.out.println("--------------");
    }

    public void ver2(){

        Iterator<ForeignKeys>ite=listaFK.iterator();
        while (ite.hasNext() ){
            ForeignKeys aux=ite.next();
            aux.ver3();

        }
    }


}
