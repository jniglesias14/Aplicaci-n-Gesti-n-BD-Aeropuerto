import java.util.ArrayList;

public class RelacionesFK {
    public String nombre;
    public ArrayList<String>lista;
    public RelacionesFK(String n){
        this.nombre=n;
        lista=new ArrayList<>();
    }
}
