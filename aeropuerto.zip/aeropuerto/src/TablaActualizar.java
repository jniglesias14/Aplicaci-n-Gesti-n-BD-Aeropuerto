import java.util.ArrayList;

public class TablaActualizar {
    protected String nombre;
    protected ArrayList<String> columnas;
    protected ArrayList<String> valoresSeleccionados;

    public TablaActualizar(String n){
        this.nombre=n;
        columnas=new ArrayList<>();
        valoresSeleccionados=new ArrayList<>();
    }


}
