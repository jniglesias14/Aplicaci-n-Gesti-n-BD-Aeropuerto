import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Tablas {
    public static String comprobarTabla(Connection con){
        Scanner teclado=new Scanner(System.in);
            ArrayList<String> nombresTablas = new ArrayList<>();
            try {
                DatabaseMetaData metaDatos = con.getMetaData();
                ResultSet rs = metaDatos.getTables("aeropuerto", null, "%", new String[]{"TABLE"});
                while (rs.next()) {
                    String nombreTabla = rs.getString("TABLE_NAME");
                    nombresTablas.add(nombreTabla);
                }
                for(String s:nombresTablas){
                    System.out.println(s);
                }
                System.out.println("Selecciona la tabla: ");
                String nombre=teclado.nextLine();
                if(seleccionar(nombresTablas,nombre)){
                    return nombre;
                }else{
                    return null;
                }
            } catch (SQLException sqle) {
                sqle.printStackTrace();
                return null;
            }
    }

    public static boolean seleccionar(ArrayList<String> lista,String nombre){
        Iterator<String> ite =lista.iterator();
        while(ite.hasNext()){
            String aux=ite.next();
            if(aux.equals(nombre)){
                return true;
            }
        }
        return false;
    }
}

